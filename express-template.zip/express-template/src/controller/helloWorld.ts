import { Request, RequestHandler, Response, NextFunction } from "express";

export const helloWorld: RequestHandler = async (req: Request, res: Response, next: NextFunction) => {
    res.json({ message: "Hello World" });
};
