import { Request, RequestHandler, Response, NextFunction } from "express";
const jinst = require('jdbc/lib/jinst');
const JDBC = require('jdbc');
const asyncjs = require('async');

const config = {
    url: 'jdbc:mysql://localhost:3306/btc_apigw',
    drivername: 'com.mysql.jdbc.Driver',
    minpoolsize: 5,
    maxpoolsize: 10,
    user: 'root',
    password: 'mariadb',
    properties: {}
};

export const mySqlAccess: RequestHandler = async (req: Request, res: Response, next: NextFunction) => {
    const sql: string = req.query.sql;
    console.log("arg:" + sql);

    if (!jinst.isJvmCreated()) {
        jinst.addOption("-Xrs");
        const cp = 'jar/mysql-connector-java-5.1.47.jar';
        console.log("class path=" + cp);
        jinst.setupClasspath([cp]);
    }

    const database = new JDBC(config);
    database.initialize(function (err) {
        if (err) {
            console.error("Error occurred:" + err);
            console.log(err);
        }
    });

    database.reserve(function (err, connObj) {
        if (connObj) {
            console.log("Using connection: " + connObj.uuid);
            const conn = connObj.conn;

            asyncjs.series([
                function (callback) {
                    conn.createStatement(function (err, statement) {
                        if (err) {
                            console.error("Error occurred:" + err);
                            callback(err);
                        } else {
                            statement.setFetchSize(100, function (err) {
                                if (err) {
                                    console.error("Error occurred:" + err);
                                    callback(err);
                                } else {
                                    console.log("Sql: " + sql);
                                    statement.executeQuery(sql,
                                        function (err, resultset) {
                                            if (err) {
                                                console.error("Error occurred:" + err);
                                                callback(err)
                                            } else {
                                                resultset.toObjArray(function (err, results) {
                                                    if (results.length > 0) {
                                                        console.log("Record count: " + results.length);
                                                        console.log(results);
                                                    }
                                                    callback(null, resultset);
                                                });
                                            }
                                        });
                                }
                            });
                        }
                    });
                },
            ], function (err, results) {
                database.release(connObj, function (err) {
                    if (err) {
                        console.error("Error occurred:" + err);
                        console.log(err.message);
                    }
                });
            });
        }
    });

    res.json({ message: "SQL execute completed" });
};

async function sleep(time: number) {
	return new Promise((resolve, reject) => {
		setTimeout(() => {
			resolve();
		}, time);
	});
};
