import * as express from "express";
import { NextFunction, Request, Response } from "express";
import { asyncHandler } from "../handler/asyncHandler";
import { helloWorld } from "../controller/helloWorld";
import { mySqlAccess } from "../controller/mySqlAccess";

var router = express.Router();

router.get('/', function (req: Request, res: Response, next: NextFunction) {
  res.json({ message: "Hello express-template world" });
});
router.get("/hello", asyncHandler(helloWorld));
router.get("/mysql-access", asyncHandler(mySqlAccess));

export default router;